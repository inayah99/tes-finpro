import React from 'react'

const Recipes = () => {
  return (
    <div>Recipes</div>
  )
}

export default Recipes