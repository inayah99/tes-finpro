import React,{useState} from 'react'
import { Link } from 'react-router-dom'
import './login.css'
import logo from './logo.png'
import welcome from './welcome.png'

const Login = () => {

    const[emailval, setemailval]= useState("");
    const[passval, setpassval]= useState("")

    const handlesubmit =(event)=>{
        event.preventDefault();
    }
  return (
    <div className='main-login'>
        <div className="login-container">
            <div className="left-side">
                <div className="img-class">
                    <img className="img-id" src={logo} alt="logo" srcset="" />
                </div>
                <form onSubmit={handlesubmit}>
                <label className="left-label" for="email">Email</label>
                    <input placeholder='Enter your email' type="email" value={emailval} onChange={(e)=>{setemailval(e.target.value)}} id="email"/>
                <label className="left-label" for="pwd">Password</label>
                    <input placeholder='Enter your password' type="password" value={passval} onChange={(e)=>{setpassval(e.target.value)}} id="pwd"/>
                    <button type='submit' id="button">Submit</button>
                </form>
                <div className="footer">
                    <h5>Don't have an account? <Link className="link" to='/register'>Sign Up</Link></h5> 
                </div>
            </div>
            <div className="right-side">
                {/* <div className="welcome">
                    <h3>Welcome Back...</h3>
                </div> */}
                <div className="welcomeimg">
                    <img className="welcome-img" src={welcome} alt="" srcset="" />
                </div>
            </div>
        </div> 
        
    </div>
  )
}

export default Login