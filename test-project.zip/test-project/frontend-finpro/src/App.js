import './App.css';
// import Sidebar from './components/Sidebar.jsx';
import {Route, Routes, BrowserRouter as Router, Link} from 'react-router-dom';
// import Dashboard from './pages/Dashboard';
// import Logout from './pages/Logout';
// import Recipes from './pages/Recipes';
// import Userlists from './pages/Userlists';
import Login from './components/Login/Login.jsx';
import Register from './components/Register/Register.jsx';


function App() {
  return (
    <div>
        <Router>
          <Link to='/login'>Login</Link>
          <Link to='/register'>Register</Link>
         
          <Routes>
        <Route path="/register" element={<Register />}></Route>
        <Route path="/login" element={<Login />}></Route>
          </Routes>
        {/* <Sidebar> */}
          {/* <Routes>
            <Route path="/dashboard" element={<Dashboard />}></Route>
            <Route path="/logout" element={<Logout />}></Route>
            <Route path="/recipes" element={<Recipes />}></Route>
            <Route path="/userlists" element={<Userlists />}></Route>
            </Routes> */}
          {/* </Sidebar> */}
        </Router>
     

    </div>
  );
}

export default App;
